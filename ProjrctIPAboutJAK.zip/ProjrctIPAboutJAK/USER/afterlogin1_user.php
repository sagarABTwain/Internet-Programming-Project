<?php session_start();
include "../ALL/db.php";?>
<?php
				$header=$_POST['header'];
				$status=$_POST['status'];
				$user_id=$_SESSION['id'];
				
				$timezone = date("D, d M Y H:i:s A");
				$prefix=$_SESSION['id'].time();
				$link1=$_FILES['fileToUpload']['type'];
				
				$allowed =  array('gif','png' ,'jpg', 'PNG','JPG','JPEG','jpeg');
				$filename = $_FILES['fileToUpload']['name'];
				$ext = pathinfo($filename, PATHINFO_EXTENSION);
				
				if(!in_array($ext,$allowed) ) {
					$file_type=0;
				}
				else {
					$file_type=1;
				}
				
				
	
				$link="../upload/".$prefix. basename($_FILES["fileToUpload"]["name"]);
				move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$link);
				
				if(file_exists($link))
				$sql="INSERT INTO post(post_text,time,post_header,user_id,link,file_type)VALUES('$status','$timezone','$header','$user_id','$link','$file_type')";
				else
				$sql="INSERT INTO post(post_text,time,post_header,user_id)VALUES('$status','$timezone','$header','$user_id')";
				mysql_query($sql);
				header("location:afterlogin_user.php");
				
?>

