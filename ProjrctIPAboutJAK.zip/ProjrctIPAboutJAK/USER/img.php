<html>
<body>
	<img src=<?php echo $_GET['link'];?> style="location:null;"></img>
	
</body>
</html>